import ArtistLayout from '@/Layouts/ArtistLayout';
import { Head, Link } from '@inertiajs/react';

const money = (value, currency = 'INR') =>
    new Intl.NumberFormat('en-IN', {
        style: 'currency',
        currency,
        maximumFractionDigits: 2,
    }).format(Number(value ?? 0));

const formatDate = (value) => {
    if (!value) return '—';

    return new Intl.DateTimeFormat('en-IN', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
    }).format(new Date(value));
};

export default function Dashboard({
    artist = {},
    stats = {},
    recentReleases = [],
    recentTransactions = [],
    recentWithdrawals = [],
}) {
    const currency = stats.currency || artist.currency || 'INR';

    const cards = [
        {
            title: 'Total Releases',
            value: Number(stats.total_releases ?? 0).toLocaleString('en-IN'),
            note: 'Total music submissions',
            icon: '♫',
        },
        {
            title: 'Live Releases',
            value: Number(stats.live_releases ?? 0).toLocaleString('en-IN'),
            note: 'Available on stores',
            icon: '◉',
        },
        {
            title: 'Wallet Balance',
            value: money(stats.wallet_balance, currency),
            note: 'Available balance',
            icon: '₹',
        },
        {
            title: 'Pending Withdrawals',
            value: Number(
                stats.pending_withdrawals ?? 0
            ).toLocaleString('en-IN'),
            note: `Pending balance ${money(
                stats.pending_balance,
                currency
            )}`,
            icon: '↗',
        },
    ];

    return (
        <ArtistLayout
            title="Dashboard"
            subtitle={`Welcome back, ${
                artist.stage_name || artist.legal_name || 'Artist'
            }`}
        >
            <Head title="Artist Dashboard" />

            <section className="overflow-hidden rounded-3xl bg-[#0d1526] px-7 py-8 text-white shadow-xl lg:px-10">
                <div className="flex flex-col justify-between gap-6 lg:flex-row lg:items-center">
                    <div>
                        <p className="text-sm font-medium text-slate-400">
                            ARTIST OVERVIEW
                        </p>

                        <h2 className="mt-2 text-3xl font-bold lg:text-4xl">
                            Hello,{' '}
                            {artist.stage_name ||
                                artist.legal_name ||
                                'Artist'}
                        </h2>

                        <p className="mt-3 max-w-2xl text-sm leading-6 text-slate-300">
                            Manage releases, monitor royalties and track your
                            wallet activity from one place.
                        </p>

                        <div className="mt-5 flex flex-wrap gap-3 text-xs">
                            <span className="rounded-full bg-white/10 px-3 py-2">
                                Account: {artist.account_status || 'active'}
                            </span>

                            <span className="rounded-full bg-white/10 px-3 py-2">
                                KYC: {artist.kyc_status || 'pending'}
                            </span>
                        </div>
                    </div>

                    <Link
                        href="/releases/create"
                        className="w-fit rounded-xl bg-white px-6 py-3 text-sm font-semibold text-[#0d1526]"
                    >
                        + Create Release
                    </Link>
                </div>
            </section>

            <section className="mt-6 grid gap-5 sm:grid-cols-2 xl:grid-cols-4">
                {cards.map((card) => (
                    <article
                        key={card.title}
                        className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm"
                    >
                        <div className="flex items-start justify-between">
                            <div>
                                <p className="text-sm font-medium text-slate-500">
                                    {card.title}
                                </p>

                                <p className="mt-3 text-3xl font-bold text-slate-900">
                                    {card.value}
                                </p>

                                <p className="mt-3 text-xs text-slate-400">
                                    {card.note}
                                </p>
                            </div>

                            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-slate-100 text-lg font-bold text-[#0d1526]">
                                {card.icon}
                            </div>
                        </div>
                    </article>
                ))}
            </section>

            <section className="mt-6 grid gap-6 xl:grid-cols-[1.5fr_1fr]">
                <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
                    <div className="flex items-center justify-between border-b border-slate-200 px-6 py-5">
                        <div>
                            <h3 className="text-lg font-bold text-slate-900">
                                Recent Releases
                            </h3>

                            <p className="mt-1 text-sm text-slate-500">
                                Your latest music submissions.
                            </p>
                        </div>

                        <Link
                            href="/releases"
                            className="rounded-xl border border-slate-200 px-4 py-2 text-sm font-semibold text-slate-700"
                        >
                            View All
                        </Link>
                    </div>

                    {recentReleases.length > 0 ? (
                        <div className="divide-y divide-slate-100">
                            {recentReleases.map((release) => (
                                <div
                                    key={release.id}
                                    className="flex items-center justify-between gap-4 px-6 py-4"
                                >
                                    <div className="min-w-0">
                                        <p className="truncate font-semibold text-slate-900">
                                            {release.title || 'Untitled Release'}
                                        </p>

                                        <p className="mt-1 text-xs text-slate-500">
                                            {release.release_type || 'Release'} ·{' '}
                                            {formatDate(
                                                release.digital_release_date ||
                                                    release.created_at
                                            )}
                                        </p>
                                    </div>

                                    <span className="rounded-full bg-slate-100 px-3 py-1 text-xs font-semibold capitalize text-slate-700">
                                        {release.status || 'draft'}
                                    </span>
                                </div>
                            ))}
                        </div>
                    ) : (
                        <div className="p-8 text-center">
                            <p className="font-semibold text-slate-800">
                                No releases found
                            </p>

                            <Link
                                href="/releases/create"
                                className="mt-4 inline-flex rounded-xl bg-[#0d1526] px-5 py-3 text-sm font-semibold text-white"
                            >
                                Create First Release
                            </Link>
                        </div>
                    )}
                </div>

                <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
                    <h3 className="text-lg font-bold text-slate-900">
                        Quick Actions
                    </h3>

                    <div className="mt-5 space-y-3">
                        {[
                            ['Create New Release', '/releases/create'],
                            ['View Catalogue', '/catalogue'],
                            ['Monthly Royalties', '/royalties'],
                            ['Open Wallet', '/wallet'],
                            ['Request Withdrawal', '/withdrawals'],
                            ['Profile & KYC', '/profile'],
                        ].map(([label, href]) => (
                            <Link
                                key={label}
                                href={href}
                                className="flex items-center justify-between rounded-xl border border-slate-200 px-4 py-4 text-sm font-semibold text-slate-700 transition hover:bg-slate-50"
                            >
                                <span>{label}</span>
                                <span className="text-slate-400">›</span>
                            </Link>
                        ))}
                    </div>
                </div>
            </section>

            <section className="mt-6 grid gap-6 xl:grid-cols-2">
                <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
                    <div className="border-b border-slate-200 px-6 py-5">
                        <h3 className="text-lg font-bold text-slate-900">
                            Recent Wallet Transactions
                        </h3>
                    </div>

                    {recentTransactions.length > 0 ? (
                        <div className="divide-y divide-slate-100">
                            {recentTransactions.map((transaction) => (
                                <div
                                    key={transaction.id}
                                    className="flex items-center justify-between gap-4 px-6 py-4"
                                >
                                    <div>
                                        <p className="font-semibold text-slate-900">
                                            {transaction.description ||
                                                transaction.transaction_type}
                                        </p>

                                        <p className="mt-1 text-xs text-slate-500">
                                            {formatDate(
                                                transaction.posted_at ||
                                                    transaction.created_at
                                            )}
                                        </p>
                                    </div>

                                    <div className="text-right">
                                        <p
                                            className={`font-bold ${
                                                transaction.direction ===
                                                'credit'
                                                    ? 'text-emerald-600'
                                                    : 'text-rose-600'
                                            }`}
                                        >
                                            {transaction.direction === 'credit'
                                                ? '+'
                                                : '-'}
                                            {money(
                                                transaction.amount,
                                                transaction.currency || currency
                                            )}
                                        </p>

                                        <p className="mt-1 text-xs capitalize text-slate-500">
                                            {transaction.status || 'posted'}
                                        </p>
                                    </div>
                                </div>
                            ))}
                        </div>
                    ) : (
                        <div className="p-8 text-center text-sm text-slate-500">
                            No wallet transactions yet.
                        </div>
                    )}
                </div>

                <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
                    <div className="flex items-center justify-between border-b border-slate-200 px-6 py-5">
                        <h3 className="text-lg font-bold text-slate-900">
                            Recent Withdrawals
                        </h3>

                        <Link
                            href="/withdrawals"
                            className="text-sm font-semibold text-violet-600"
                        >
                            View All
                        </Link>
                    </div>

                    {recentWithdrawals.length > 0 ? (
                        <div className="divide-y divide-slate-100">
                            {recentWithdrawals.map((withdrawal) => (
                                <div
                                    key={withdrawal.id}
                                    className="flex items-center justify-between gap-4 px-6 py-4"
                                >
                                    <div>
                                        <p className="font-semibold text-slate-900">
                                            {withdrawal.withdrawal_number}
                                        </p>

                                        <p className="mt-1 text-xs text-slate-500">
                                            {formatDate(
                                                withdrawal.requested_at
                                            )}
                                        </p>
                                    </div>

                                    <div className="text-right">
                                        <p className="font-bold text-slate-900">
                                            {money(
                                                withdrawal.amount,
                                                withdrawal.currency || currency
                                            )}
                                        </p>

                                        <span className="mt-1 inline-flex rounded-full bg-slate-100 px-3 py-1 text-xs font-semibold capitalize text-slate-700">
                                            {withdrawal.status}
                                        </span>
                                    </div>
                                </div>
                            ))}
                        </div>
                    ) : (
                        <div className="p-8 text-center text-sm text-slate-500">
                            No withdrawal requests yet.
                        </div>
                    )}
                </div>
            </section>
        </ArtistLayout>
    );
}
